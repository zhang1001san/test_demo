package com.it.springvue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringvueApplicationTests {

    @Test
    void contextLoads() {
    }

}
