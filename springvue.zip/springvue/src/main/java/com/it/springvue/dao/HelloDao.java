package com.it.springvue.dao;

import com.it.springvue.entity.UserEntity;

import java.util.List;

/**
 * @author:zhang
 * @since:2020/7/4
 */
public interface HelloDao {

    public List<UserEntity> getUsers();
}
