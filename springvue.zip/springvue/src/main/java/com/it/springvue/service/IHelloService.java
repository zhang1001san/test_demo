package com.it.springvue.service;

import com.it.springvue.entity.UserEntity;

import java.util.List;

/**
 * @author:zhang
 * @since:2020/7/4
 */
public interface IHelloService {
    public List<UserEntity> getUsers();
}
