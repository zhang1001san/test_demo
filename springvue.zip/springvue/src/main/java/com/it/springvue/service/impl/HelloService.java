package com.it.springvue.service.impl;

import com.it.springvue.dao.HelloDao;
import com.it.springvue.entity.UserEntity;
import com.it.springvue.service.IHelloService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author:zhang
 * @since:2020/7/4
 */
@Service
public class HelloService implements IHelloService {

    @Autowired
    private HelloDao helloDao;

    @Override
    public List<UserEntity> getUsers() {
        return helloDao.getUsers();
    }
}
