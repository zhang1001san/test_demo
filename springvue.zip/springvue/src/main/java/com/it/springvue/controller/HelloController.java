package com.it.springvue.controller;

import com.it.springvue.entity.UserEntity;
import com.it.springvue.service.IHelloService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @author:zhang
 * @since:2020/7/4
 */
@RestController
@RequestMapping("/hello")
public class HelloController {
    @Autowired
    private IHelloService helloService;

    @RequestMapping("/getUsers")
    public List<UserEntity> getUsers(){
        return helloService.getUsers();
    }
}
