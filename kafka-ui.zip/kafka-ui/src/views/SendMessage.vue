<template>
  <div>
    <el-card>
      <el-form :model="messageForm" :rules="messageRules" ref="messageRuleFormRef" label-width="100px"
      >
        <el-form-item label="topic" prop="topic">
          <el-select
              filterable
              allow-create
              default-first-option
              v-model="messageForm.topic"
              placeholder="请选择topic">
            <el-option
                v-for="item in topics"
                 :key="item.value"
                 :label="item.label"
                 :value="item.value"
            ></el-option>

          </el-select>
        </el-form-item>
        <el-form-item label="event" prop="event">
          <el-input v-model="messageForm.event"></el-input>
        </el-form-item>
        <el-form-item label="subEvent">
          <el-input v-model="messageForm.subEvent"></el-input>
        </el-form-item>
        <el-form-item label="taskId" prop="taskId">
          <el-input v-model="messageForm.taskId"></el-input>
        </el-form-item>
        <el-form-item label="dcName" prop="dcName">
          <el-input v-model="messageForm.dcName"></el-input>
        </el-form-item>
        <el-form-item  label="kafka内容">
          <el-input  :rows="15"  type="textarea" v-model="messageForm.content"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button id="resetBtn" @click="resetMessageForm()">重置</el-button>
          <el-button id="submitBtn" type="primary" @click="submitMessageForm()">立即创建</el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script>
export default {
  name: "SendMessage",
  data() {
    return {
      topics:[
        {
          label:'北京',
          value:'北京'
        },
        {
          label:'上海',
          value:'上海'
        }
      ],
      messageForm: {
        topic: '',
        event: '',
        subEvent: '',
        taskId: '',
        dcName: '',
        content: ''
      },
      messageRules: {
        topic: [
          {required: true, message: '请选择发送消息的topic', trigger: 'change'}
        ],
        event: [
          {required: true, message: '请输入event', trigger: 'blur'},
        ],
        taskId: [
          {required: true, message: '请输入taskId', trigger: 'blur'},
        ],
        dcName: [
          {required: true, message: '请输入dcName', trigger: 'blur'},
        ],
      }
    }
  },
  methods: {
    submitMessageForm() {
      this.$refs.messageRuleFormRef.validate(async (valid) => {
        if (!valid) {
          return this.$message.error('请检查输入的内容是否合法!')
        }
        this.messageForm.content=JSON.parse(this.messageForm.content)
        const { data: result } = await this.$http.post('sendMessage', this.messageForm)
      });
    },
    resetMessageForm() {
      this.$refs.messageRuleFormRef.resetFields()
      this.messageForm.content=''
      this.messageForm.subEvent=''
    }
  }
}
</script>

<style scoped>
  .el-form{
    width: 1000px;
  }
</style>
