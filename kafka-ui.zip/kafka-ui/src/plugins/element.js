import Vue from 'vue';
import { Button, Card,Form,FormItem,Message,MessageBox,Select,Option,Input } from 'element-ui';
Vue.use(Button)
Vue.use(Card)
Vue.use(Form)
Vue.use(FormItem)
Vue.use(Select)
Vue.use(Option)
Vue.use(Input)
Vue.prototype.$message=Message
Vue.prototype.$confirm=MessageBox.confirm
