import Vue from 'vue'
import VueRouter from 'vue-router'
import SendMessage from "@/views/SendMessage";


Vue.use(VueRouter)

const routes = [
  {path: '/', redirect: '/sendMessage'},
  {
    path: '/sendMessage',
    name: 'SendMessage',
    component: SendMessage
  }
]

const router = new VueRouter({
  routes
})

export default router
