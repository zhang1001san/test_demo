package com.it.springbootdemo.controller;

import com.it.springbootdemo.entity.UserEntity;
import com.it.springbootdemo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @author:zhang
 * @since:2020/8/13
 */
@RestController
@RequestMapping("/hello")
public class HelloController {


    @Autowired
    private UserService userService;

    @RequestMapping("/getUser")
    public List<UserEntity> getUser() {
        return userService.getUser();
    }
}
