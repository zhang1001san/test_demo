package com.it.springbootdemo.service.iml;

import com.it.springbootdemo.entity.UserEntity;
import com.it.springbootdemo.mapper.UserMapper;
import com.it.springbootdemo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author:zhang
 * @since:2020/8/13
 */
@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserMapper userMapper;
    @Override
    public List<UserEntity> getUser() {
        return userMapper.getUser();
    }
}
