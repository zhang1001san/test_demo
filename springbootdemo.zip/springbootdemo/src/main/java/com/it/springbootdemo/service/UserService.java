package com.it.springbootdemo.service;

import com.it.springbootdemo.entity.UserEntity;

import java.util.List;

/**
 * @author:zhang
 * @since:2020/8/13
 */
public interface UserService {
    List<UserEntity> getUser();
}
