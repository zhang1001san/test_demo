package com.it.springbootdemo.mapper;

import com.it.springbootdemo.entity.UserEntity;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author:zhang
 * @since:2020/8/13
 */
@Repository
public interface UserMapper {
    List<UserEntity> getUser();
}
